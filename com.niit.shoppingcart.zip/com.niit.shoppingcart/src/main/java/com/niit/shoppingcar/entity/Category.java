package com.niit.shoppingcar.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="CATEGORY")
public class Category 
{
    //Properties
	@Id
	private String id;
	private String name;
	private String description;
	
	public String getId() {
		return id;
	}
	
	//Getters and Setters
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
