package com.niit.shoppingcart.impl;

import java.util.List;

import javax.transaction.Transactional;


import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcar.entity.Category;
import com.niit.shoppingcartDAO.CategoryDAO;


@Repository(value="categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	
	private static final Logger log = LoggerFactory.getLogger(CategoryDAOImpl.class); 
	
	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	public CategoryDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	/*save - save the record - if the record exist, it will throw error
	  update - update the record - if the record does not exist, it will throw error
	  saveorupdate - if the record exist, it will update
	               - if the record does not exist, it will create
	*/
	
	@Transactional
	public boolean save(Category category) {
		
		try {
			log.debug("Starting of the method save");
			sessionFactory.getCurrentSession().save(category);
			log.debug("Ending of the method save");
			return true;
		} catch (Exception e) {
			log.error("Exception occured in save method" + e.getMessage());
			e.printStackTrace();
			return false;
		}
		
	}

	@Transactional
	public boolean update(Category category) {
		try {
			log.debug("Starting of the method update");
			sessionFactory.getCurrentSession().update(category);
			log.debug("Ending of the method update");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("Exception occured in update method" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	public boolean delete(Category category) {
		try {
			log.debug("Starting of the delete update");
			sessionFactory.getCurrentSession().delete(category);
			log.debug("Ending of the delete update");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("Exception occured in delete method" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	public Category get(String id) {
		log.info("Trying to get Category based on id: "+id);
		//select * from category where id = '101'
		String hql = " from Category where id =  "+ " ' "+id + " ' ";
		log.info("The hsql query is : "+hql);
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Category> list = query.list();
		
		if(list==null)
		{
			log.info("No categories present");
			return null;
		}
		else
		{
			return list.get(0);
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Category> list() {
		
		String hql = " from Category ";
		
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

}
