package com.niit.shoppingcart.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.niit.shoppingcar.entity.Supplier;
import com.niit.shoppingcartDAO.SupplierDAO;


@Repository(value="supplierDAO")

public class SupplierDAOImpl implements SupplierDAO {
	private static final Logger log = LoggerFactory.getLogger("SupplierDAOImpl.class");
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public SupplierDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	/*save - save the record - if the record exist, it will throw error
	  update - update the record - if the record does not exist, it will throw error
	  saveorupdate - if the record exist, it will update
	               - if the record does not exist, it will create
	*/
	
	@Transactional
	public boolean save(Supplier supplier) {
		
		try {
			log.debug("Starting of save method");
			sessionFactory.getCurrentSession().save(supplier);
			log.debug("Ending of method save");
			return true;
		} catch (HibernateException e) {
			log.error("Exception occured in method save", e.getMessage());
			e.printStackTrace();
			return false;
		}
		
	}

	@Transactional
	public boolean update(Supplier supplier) {
		try {
			log.debug("Starting of update method");
			sessionFactory.getCurrentSession().update(supplier);
			log.debug("Ending of method update");
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			log.error("Exception occured in method update", e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	public boolean delete(Supplier supplier) {
		try {
			log.debug("Starting of delete method");
			sessionFactory.getCurrentSession().delete(supplier);
			log.debug("Ending of method delete");
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			log.error("Exception occured in method delete", e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	
	public Supplier get(String id) {
		//select * from supplier where id = '101'
		String hql = " from Supplier where id =  "+ " ' "+id + " ' ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Supplier> list = query.list();
		
		if(list==null)
		{
			return null;
		}
		else
		{
			return list.get(0);
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional
	
	public List<Supplier> list() {
		
		String hql = " from Supplier ";
		
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

}
