package com.niit.shoppingcart.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.niit.shoppingcar.entity.Product;
import com.niit.shoppingcartDAO.ProductDAO;


@Repository(value="productDAO")

public class ProductDAOImpl implements ProductDAO {
	
	private static final Logger log = LoggerFactory.getLogger(ProductDAOImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public ProductDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	/*save - save the record - if the record exist, it will throw error
	  update - update the record - if the record does not exist, it will throw error
	  saveorupdate - if the record exist, it will update
	               - if the record does not exist, it will create
	*/
	
	@Transactional
	public boolean save(Product product) {
		
		try {
			log.debug("Starting of method save");
			sessionFactory.getCurrentSession().save(product);
			log.debug("Ending of method save");
			return true;
		} catch (HibernateException e) {
			log.error("Exception occured in save method", e.getMessage());
			e.printStackTrace();
			return false;
		}
		
	}

	@Transactional
	public boolean update(Product product) {
		try {
			log.debug("Starting of method update");
			sessionFactory.getCurrentSession().update(product);
			log.debug("Ending of method update");
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			log.error("Exception occured in update method", e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	public boolean delete(Product product) {
		try {
			log.debug("Starting of method delete");
			sessionFactory.getCurrentSession().delete(product);
			log.debug("Ending of method delete");
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			log.error("Exception occured in delete method", e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	
	public Product get(String id) {
		log.info("Trying to get Product based on id: "+id);
		//select * from product where id = '101'
		String hql = " from Product where id =  "+ " ' "+id + " ' ";
		log.info("The hsql query is: " + hql);
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Product> list = query.list();
		
		if(list==null)
		{
			log.info("No products are available");
			return null;
		}
		else
		{
			return list.get(0);
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional
	
	public List<Product> list() {
		
		String hql = " from Product ";
		
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

}
