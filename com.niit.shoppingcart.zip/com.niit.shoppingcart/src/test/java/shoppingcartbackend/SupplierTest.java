package shoppingcartbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcar.entity.Supplier;
import com.niit.shoppingcartDAO.SupplierDAO;

public class SupplierTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
        context.refresh();
        
        SupplierDAO supplierDAO = (SupplierDAO)context.getBean("SupplierDAO");
        
        Supplier supplier = (Supplier)context.getBean("supplier");
        
        supplier.setId("SUP001");
        supplier.setName("Flying_Machine");
        supplier.setAddress("Ahmedabad India");
        
        if(supplierDAO.save(supplier)==true)
        {
        	System.out.println("success");
        }
        else
        {
        	System.out.println("failure");
        }
        context.close();
	}

}
