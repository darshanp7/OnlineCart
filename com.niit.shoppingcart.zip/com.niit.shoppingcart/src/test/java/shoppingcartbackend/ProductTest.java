package shoppingcartbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shoppingcar.entity.Product;
import com.niit.shoppingcartDAO.ProductDAO;


public class ProductTest {
	
		  public static void main(String[] args) {

			  AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		      context.scan("com.niit.*");
		      context.refresh();
		      
			  ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
			  
			  Product product = (Product)context.getBean("product");
			  
			  product.setId("PD001");
			  product.setName("Jeans");
			  product.setPrice(2000);
			  product.setCategory_id("CG001");
			  product.setSupplier_id("SUP001");
			  
			  if(productDAO.save(product)==true)
			  {
			  System.out.println("success");
			  }
			  else
			  {
				  System.out.println("failed");
			  }
			  context.close();
		}
			

}
