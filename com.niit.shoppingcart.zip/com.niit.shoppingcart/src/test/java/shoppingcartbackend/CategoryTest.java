package shoppingcartbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcar.entity.Category;
import com.niit.shoppingcartDAO.CategoryDAO;


public class CategoryTest {
	
		  public static void main(String[] args) {

			  AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		      context.scan("com.niit.*");
		      context.refresh();
		      
			  CategoryDAO categoryDAO = (CategoryDAO)context.getBean("categoryDAO");
			  
			  Category category = (Category)context.getBean("category");
			  
			  category.setId("CG003");
			  category.setName("FEM_DRESS");
			  category.setDescription("Formal");
			  
			  if(categoryDAO.save(category)==true)
			  {
			  System.out.println("success");
			  }
			  else
			  {
				  System.out.println("failed");
			  }
			  context.close();
		}
			

}
