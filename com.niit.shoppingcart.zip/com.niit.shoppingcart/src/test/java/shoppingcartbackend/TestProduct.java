package shoppingcartbackend;

import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.Before;

import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shoppingcar.entity.Product;
import com.niit.shoppingcartDAO.ProductDAO;

public class TestProduct {

	static ProductDAO productDAO;
	static Product product;
	static AnnotationConfigApplicationContext context;
	
	@Before
	public static void init()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		productDAO=(ProductDAO) context.getBean("ProductDAO");
    	product=(Product) context.getBean("product");
    }
    
    @AfterClass
    public static void close()
    {
    	context.close();
    	productDAO=null;
    	product=null;
    }
    
    @Test
    public void productTestCase() {
    	int size=productDAO.list().size();
    	assertEquals("Product list test case",1,size);
    }
    
    /*@Test
    public void userNameTestCase()
    {
    	product=productDAO.get("PD001");
    	String name=product.getName();
    	assertEquals("Name test case","Jeans",name);
    }
	*/

}
