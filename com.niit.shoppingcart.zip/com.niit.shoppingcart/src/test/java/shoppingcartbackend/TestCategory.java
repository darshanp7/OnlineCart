package shoppingcartbackend;


import static org.junit.Assert.*;
import org.junit.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcar.entity.Category;
import com.niit.shoppingcartDAO.CategoryDAO;

public class TestCategory {
	static CategoryDAO categoryDAO;
	static Category category;
	static AnnotationConfigApplicationContext context;
    @Before
    public void init()
    {
    	context=new AnnotationConfigApplicationContext();
    	context.scan("com.niit.*");
    	context.refresh();
    	categoryDAO=(CategoryDAO) context.getBean("categoryDao");
    	category=(Category) context.getBean("category");
    }
    
    
    
    @Test
    public void categoryTestCase() {
    	int size=categoryDAO.list().size();
    	assertEquals("Category list test case",2,size);
    }
    
    /*@Test
    public void userNameTestCase()
    {
    	category=categoryDAO.get("CG001");
    	String name=category.getDescription();
    	assertEquals("Name test case","Men Casual",name);
    }
    */
}
