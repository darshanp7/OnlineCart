package com.niit.shoppingcart;

@Controller
public class HomeController {

/*	If you want to navigate to other page without carrying data.
 *  @RequestMapping("/")
	public String home()
	{
		return "Home";
	}
*/	
	//If you want to navigate to other page with carrying the data
	
	@RequestMapping("/")
    public ModelAndView home()
	{
    	ModelAndView mv = new ModelAndView("Home");
		mv.addObject("message","Thank you for visiting this URL");
		
		return mv;
	}
	
	@RequestMapping("/Register")
	public ModelAndView register()
	{
		ModelAndView mv = new ModelAndView("Registration");
		return mv;
	}
	
	@RequestMapping("/Login")
	public ModelAndView login()
	{
		ModelAndView mv = new ModelAndView("Login");
		return mv;
	}
}
